document.getElementById("modalNewItem").onclick = function(){
	document.getElementById("modal-add").style.display = "block";
}

document.getElementById("closeAdd").onclick = function() {
	document.getElementById("modal-add").style.display = "none";
}

document.getElementById("closeMod").onclick = function(){
	document.getElementById("modal-mod").style.display = "none";
}

window.onclick = function(event){
	if(event.target == document.getElementById("modal-mod"))
		document.getElementById("modal-mod").style.display = "none";
	if(event.target == document.getElementById("modal-add"))
		document.getElementById("modal-add").style.display = "none";
}

function modProdotto(element) {
    document.getElementById("modal-mod").style.display = "block";

    document.getElementById("modId").value = element.getAttribute('data-id');
    document.getElementById("modNome").value = element.getAttribute('data-nome');
    document.getElementById("modDataScadenza").value = element.getAttribute('data-data_scadenza');
    document.getElementById("modQuantita").value = element.getAttribute('data-quantita');
    document.getElementById("modDescrizione").value = element.getAttribute('data-descrizione');
    document.getElementById("modPrezzo").value = element.getAttribute('data-prezzo');
    document.getElementById("modAlimento").checked = element.getAttribute('data-alimento');
    document.getElementById("modStato").value = element.getAttribute('data-stato');
}

 function showEdibleProducts() {
        // Ottieni la tabella dei prodotti
        var table = document.getElementById("elenco");

        // Itera attraverso le righe della tabella
        for (var i = 0; i < table.rows.length; i++) {
            var row = table.rows[i];

            // Ottieni lo stato del prodotto nella colonna corrispondente
            var stato = row.cells[7].innerText;

            // Nascondi o mostra la riga in base allo stato del prodotto
            if (stato === "edibile" || stato === "inScadenza") {
                row.style.display = "table-row";
            } else {
                row.style.display = "none";
            }
        }
    }

function showEdibleProducts() {
    console.log("sono dentro la function");
        // Ottieni la tabella dei prodotti
        var table = document.getElementById("elenco");
        console.log(table);

        // Itera attraverso le righe della tabella
        for (var i = 0; i < table.rows.length; i++) {
            var row = table.rows[i];
            console.log(row)
            // Ottieni lo stato del prodotto nella colonna corrispondente
            var stato = row.cells[7].innerText;

            // Nascondi o mostra la riga in base allo stato del prodotto
            if (stato === "Edibile" || stato === "In scadenza") {
                row.style.display = "table-row";
            } else {
                row.style.display = "none";
            }
        }
    }


