function handleRuoloChange() {
        var ruoloSelect = document.getElementById("ruolo");
        var nomeField = document.getElementById("nome");

        if (ruoloSelect.value === "azienda") {
            nomeField.placeholder = "Nome azienda";
            document.getElementById("cognomeField").style.display = "none";
        } else {
            nomeField.placeholder = "Inserire nome";
            document.getElementById("cognomeField").style.display = "block";
        }
    }